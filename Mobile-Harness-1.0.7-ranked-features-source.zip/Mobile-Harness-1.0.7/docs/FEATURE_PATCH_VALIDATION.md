# Mobile Harness 1.0.7 — feature patch validation

This patch adds the first ten items ranked in [`FEATURE_ROADMAP_30.md`](FEATURE_ROADMAP_30.md).

## What was added

1. Local endpoint presets for Ollama, llama.cpp server, LM Studio, and LocalAI.
2. Normalization of common pasted API endpoint URLs before discovery, validation, and profile saving.
3. Best-effort custom API protocol inference, with an editable protocol selector.
4. Endpoint destination and transport privacy hints; public plain HTTP is reported as blocked.
5. Keyless Custom API discovery/validation paths for compatible local servers.
6. Configurable 30–600 second Claude Code approval timeout.
7. A separately testable permission-hook generator that avoids Kotlin/shell variable interpolation collisions and denies on timeout or non-allow responses.
8. Expanded destructive-command risk heuristics.
9. Approval cards with risk labels, affected paths, and expandable command previews; long commands show an explicit truncation marker.
10. A one-task acknowledgement before DeepSeek Harness or Antigravity tasks, which do not yet use the app's per-action approval bridge.

## Verification performed

- Compiled the endpoint/helper and risk-classifier Kotlin sources with `kotlinc` and ran focused assertions.
- Compiled the permission-hook generator, generated the shell script, and verified its syntax with `sh -n`.
- Parsed all 61 Android resource XML files and checked that all new string resources exist.

## Verification limitation

`./gradlew testDebugUnitTest --no-daemon` could not start because the Gradle wrapper could not resolve `services.gradle.org` (`UnknownHostException`). Therefore the complete Android/Compose project has **not** been built or tested, and this patch does not include a verified APK.

## Important behavior limits

- Local presets only configure a connection. The model server must already be installed/running, and model weights must already be available. The patch does not bundle an inference engine or model weights into the APK.
- Per-action approval remains implemented for Claude Code only. The new DSH/Antigravity dialog is a per-task acknowledgement, not an individual command permission prompt.
- Risk labels are heuristics for review; they are not a sandbox or a guarantee that a command is safe.
