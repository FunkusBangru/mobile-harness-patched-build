# Mobile Harness — 30-feature engineering rank

**Ranking method.** Candidates are ranked by user impact, practical feasibility in the current Android/PRoot architecture, and safety/reliability benefit. Scores are engineering estimates, not benchmark results. Effort: S = small, M = medium, L = large, XL = substantial/upstream-dependent. The first 10 are included in this patch.

| Rank | Candidate feature | Impact | Effort | Decision |
|---:|---|:---:|:---:|---|
| 1 | Local-model connection presets for Ollama, llama.cpp server, LM Studio, and LocalAI | Very high | S | **Implemented** |
| 2 | Normalize pasted model endpoint URLs before discovery/validation and before saving profiles | High | S | **Implemented** |
| 3 | Infer custom API protocol from a pasted endpoint and configure the preset accordingly | High | S | **Implemented** |
| 4 | Explain whether the configured endpoint is this phone, a private network, remote HTTPS, or blocked public HTTP | Very high | S | **Implemented** |
| 5 | Make the keyless local Custom API path discoverable, with explicit model-server setup guidance | High | S | **Implemented** |
| 6 | Configurable timeout for Claude Code tool-approval requests, with a deny-on-timeout policy | Very high | S | **Implemented** |
| 7 | Generate the approval shell hook without Kotlin/shell interpolation collisions; retain deny-on-error behavior | Very high | S | **Implemented** |
| 8 | Classify more destructive shell patterns as high risk instead of relying on a short substring list | High | S | **Implemented** |
| 9 | Show risk level and the exact command preview on each Claude Code approval card | High | M | **Implemented** |
| 10 | Require a one-task acknowledgement before running agents that do not expose Mobile Harness per-tool approval | Very high | M | **Implemented** |
| 11 | Export a support bundle with runtime diagnostics, build metadata, and automatic secret redaction | High | M | Next |
| 12 | Warn before sending prompts or attachments that appear to contain API keys, tokens, or private credentials to a remote model | Very high | M | Next |
| 13 | Project-level editable `AGENTS.md`/instruction profile with preview of what will be sent to the agent | High | M | Next |
| 14 | Estimate API spend and track usage when a provider reports token/price metadata | High | M | Next |
| 15 | Show a rough local-model RAM fit estimate for common quantized model sizes against available memory | High | M | Next |
| 16 | Provider latency and time-to-first-token test, with results stored per profile | Medium | M | Next |
| 17 | Import/export provider profiles without secrets; keys remain in Android Keystore | High | M | Next |
| 18 | Encrypted, restorable project backup with optional chats, attachments, and Git metadata | High | L | Next |
| 19 | A read-only agent mode that disables writes and shell mutations where the agent protocol supports it | Very high | L | Next |
| 20 | A shared per-action approval bridge for DeepSeek Harness and Antigravity, backed by their actual permission APIs | Very high | XL | Requires agent-specific API support; do not fake this with a prompt-only warning |
| 21 | Git branch, diff, stage, and commit controls in the workspace | High | L | Next |
| 22 | Optional post-edit test/build runner with an explicit command allowlist | High | L | Next |
| 23 | User-configurable model fallback chain for compatible providers | High | L | Next |
| 24 | Smart transient network retry with bounded backoff and clear cancellation behavior | Medium | M | Next |
| 25 | Reusable prompt/task templates with project-specific variables | Medium | M | Next |
| 26 | Voice dictation for prompts with on-device transcription when Android supports it | Medium | M | Next |
| 27 | Compare two model responses against the same read-only project context | Medium | L | Next |
| 28 | Context-window/approximate token gauge for current chat history and attached files | High | L | Next |
| 29 | Runtime resource governor for memory pressure, battery, and background process limits | High | L | Next |
| 30 | Tool/plugin or MCP server manager with per-server permissions and audit visibility | High | XL | Next |

## Implementation notes and limits

- A preset only fills endpoint settings. It does not install a model server, download model weights, or guarantee the model is already loaded.
- `127.0.0.1` is correct when the compatible server runs on the same phone. For a server on another device, enter that device's private LAN/Tailscale address and confirm that the server allows LAN connections.
- Per-action approval is still available only for Claude Code in this codebase. DeepSeek Harness and Antigravity now show a confirmation before each task, but that is **not** per-command approval; those CLIs can still execute tools automatically after confirmation.
- The shell hook denies when a response is missing, malformed, or late. The timeout setting changes only the wait duration; it never converts a timeout into approval.
