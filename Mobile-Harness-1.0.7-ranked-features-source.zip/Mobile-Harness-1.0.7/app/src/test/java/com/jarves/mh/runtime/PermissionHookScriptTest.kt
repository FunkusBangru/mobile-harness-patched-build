package com.jarves.mh.runtime

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionHookScriptTest {
    @Test
    fun shellVariablesRemainShellVariablesAndTimeoutIsConfigurable() {
        val script = PermissionHookScript.create(90)
        assertTrue(script.contains("request=\"\$bridge/\$id.request\""))
        assertTrue(script.contains("if [ \"\$count\" -ge 90 ]; then"))
        assertTrue(script.contains("decision=\"\$(cat \"\$response\""))
    }

    @Test
    fun timeoutIsBoundedAndErrorsFailClosed() {
        assertTrue(PermissionHookScript.create(1).contains("-ge 30"))
        assertTrue(PermissionHookScript.create(9999).contains("-ge 600"))
        val script = PermissionHookScript.create()
        assertTrue(script.contains("printf deny"))
        assertTrue(script.contains("\"behavior\":\"deny\""))
        assertFalse(script.contains("-ge 3000"))
    }
}
