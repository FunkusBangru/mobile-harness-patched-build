package com.jarves.mh.network

import com.jarves.mh.model.LocalModelPreset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProviderEndpointToolsTest {
    @Test
    fun normalizesPastedOpenAiEndpointPaths() {
        assertEquals("http://127.0.0.1:11434/v1", ProviderEndpointTools.normalizeBaseUrl(" http://127.0.0.1:11434/v1/chat/completions/ "))
        assertEquals("https://example.com/v1", ProviderEndpointTools.normalizeBaseUrl("https://example.com/v1/models"))
        assertEquals("https://example.com", ProviderEndpointTools.normalizeBaseUrl("https://example.com/responses"))
    }

    @Test
    fun infersCommonLocalOpenAiServers() {
        assertEquals("openai-completions", ProviderEndpointTools.inferProtocol("http://127.0.0.1:11434/v1"))
        assertEquals("openai-completions", ProviderEndpointTools.inferProtocol("http://localhost:1234/v1/chat/completions"))
        assertEquals("openai-responses", ProviderEndpointTools.inferProtocol("https://gateway.example/responses"))
        assertEquals("anthropic-messages", ProviderEndpointTools.inferProtocol("https://api.anthropic.com/v1"))
        assertEquals("anthropic-messages", ProviderEndpointTools.inferProtocol("https://gateway.example/v1/messages"))
    }

    @Test
    fun reportsEndpointPrivacyAndTransportRisk() {
        assertEquals(ProviderEndpointTools.Destination.DEVICE_LOCAL, ProviderEndpointTools.destination("http://127.0.0.1:11434/v1"))
        assertEquals(ProviderEndpointTools.Destination.PRIVATE_NETWORK, ProviderEndpointTools.destination("http://192.168.1.8:8080/v1"))
        assertEquals(ProviderEndpointTools.Destination.REMOTE_HTTPS, ProviderEndpointTools.destination("https://api.example.com/v1"))
        assertEquals(ProviderEndpointTools.Destination.INSECURE_REMOTE_HTTP, ProviderEndpointTools.destination("http://api.example.com/v1"))
    }

    @Test
    fun localPresetsUseOpenAiCompatibleProtocolAndNoEmbeddedKey() {
        assertEquals(4, LocalModelPreset.all.size)
        assertTrue(LocalModelPreset.all.all { it.protocol == "openai-completions" })
        assertTrue(LocalModelPreset.all.any { it.name == "Ollama" && it.baseUrl.contains("11434") })
        assertFalse(LocalModelPreset.all.any { it.baseUrl.contains("api-key", ignoreCase = true) })
    }
}
