package com.jarves.mh.model

/** Presets only configure an endpoint; they do not install or download model weights. */
data class LocalModelPreset(
    val name: String,
    val baseUrl: String,
    val protocol: String = "openai-completions",
    val summary: String,
) {
    companion object {
        val all: List<LocalModelPreset> = listOf(
            LocalModelPreset(
                name = "Ollama",
                baseUrl = "http://127.0.0.1:11434/v1",
                summary = "OpenAI-compatible API · default port 11434",
            ),
            LocalModelPreset(
                name = "llama.cpp server",
                baseUrl = "http://127.0.0.1:8080/v1",
                summary = "llama-server OpenAI-compatible API · default port 8080",
            ),
            LocalModelPreset(
                name = "LM Studio",
                baseUrl = "http://127.0.0.1:1234/v1",
                summary = "Local server API · default port 1234",
            ),
            LocalModelPreset(
                name = "LocalAI",
                baseUrl = "http://127.0.0.1:8080/v1",
                summary = "OpenAI-compatible local API · confirm your configured port",
            ),
        )
    }
}
