package com.jarves.mh.runtime

import com.jarves.mh.model.RiskLevel
import java.util.Locale

/** Conservative display classification; the real permission hook still decides allow/deny. */
object ToolRiskClassifier {
    private val highRiskPatterns = listOf(
        Regex("\\brm\\s+-[^\\n]*r[^\\n]*f\\b"),
        Regex("\\brm\\b[^\\n]*--recursive\\b[^\\n]*--force\\b"),
        Regex("\\brm\\b[^\\n]*--force\\b[^\\n]*--recursive\\b"),
        Regex("\\bgit\\s+reset\\s+--hard\\b"),
        Regex("\\bgit\\s+clean\\s+-[^\\s]*f[^\\s]*\\b"),
        Regex("\\bgit\\s+branch\\s+-d\\b"),
        Regex("\\bgit\\s+push\\b[^\\n]*(--force(?:-with-lease)?|\\s-f(?:\\s|$)|--delete\\b)"),
        Regex("\\bsudo\\b"),
        Regex("\\bmkfs(?:\\.[a-z0-9_-]+)?\\b"),
        Regex("\\bdd\\s+if="),
        Regex("\\bchmod\\s+-R\\s+777\\b"),
        Regex("\\bchown\\s+-R\\b"),
        Regex("\\b(curl|wget)\\b[^\\n]*\\|\\s*(sh|bash|zsh)\\b"),
        Regex("\\bfind\\b[^\\n]*\\s-delete\\b"),
        Regex("\\btruncate\\s+-s\\s*0\\b"),
        Regex("\\b(wipefs|blkdiscard|shred)\\b"),
        Regex(":\\s*\\(\\)\\s*\\{.*\\}\\s*;\\s*:", RegexOption.DOT_MATCHES_ALL),
        Regex("\\b(cat|echo|printf)\\b[^\\n]*>\\s*/dev/(sd[a-z]|nvme[0-9])\\b"),
    )

    fun classify(tool: String, command: String?): RiskLevel {
        val normalizedTool = tool.trim().lowercase(Locale.ROOT)
        val preview = "$normalizedTool ${command.orEmpty()}".lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        if (highRiskPatterns.any { it.containsMatchIn(preview) }) return RiskLevel.HIGH
        return when (normalizedTool) {
            "write", "edit", "notebookedit", "bash" -> RiskLevel.REVIEW
            else -> RiskLevel.SAFE
        }
    }
}
