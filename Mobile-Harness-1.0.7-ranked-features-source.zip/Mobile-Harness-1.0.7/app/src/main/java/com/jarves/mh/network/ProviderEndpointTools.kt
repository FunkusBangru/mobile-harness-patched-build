package com.jarves.mh.network

import java.net.URI
import java.util.Locale

/**
 * Safe, deterministic endpoint helpers shared by setup screens and tests.
 * These helpers never resolve DNS or send requests; they only inspect the URL the user supplied.
 */
object ProviderEndpointTools {
    enum class Destination(val title: String, val detail: String, val warning: Boolean) {
        DEVICE_LOCAL("This phone", "The endpoint points to this Android device. Keep its model server running.", false),
        PRIVATE_NETWORK("Private network", "Requests go to a LAN, local hostname, or private overlay address.", false),
        REMOTE_HTTPS("Remote HTTPS", "Requests go to a remote endpoint over HTTPS. Prompts and project context may leave this device.", true),
        INSECURE_REMOTE_HTTP("Blocked: public HTTP", "Plain HTTP to a public host is blocked because credentials and prompts would be unencrypted.", true),
        INVALID("Check endpoint URL", "Enter a valid http:// or https:// base URL.", true),
    }

    /** Remove common endpoint suffixes so users can paste either a base URL or a full endpoint URL. */
    fun normalizeBaseUrl(raw: String): String {
        var value = raw.trim().trimEnd('/')
        if (value.isBlank()) return ""
        val suffixes = listOf(
            "/chat/completions", "/completions", "/responses", "/messages", "/models",
        )
        var changed = true
        while (changed) {
            changed = false
            for (suffix in suffixes) {
                if (value.endsWith(suffix, ignoreCase = true)) {
                    value = value.dropLast(suffix.length).trimEnd('/')
                    changed = true
                    break
                }
            }
        }
        return value
    }

    /**
     * Best-effort protocol inference. Explicit route suffixes and known Anthropic hosts win;
     * common `/v1` roots and local server ports default to OpenAI-compatible APIs. Unknown roots
     * stay on Anthropic Messages, and the protocol remains editable by the user.
     */
    fun inferProtocol(raw: String): String {
        val rawUri = runCatching { URI(raw.trim()) }.getOrNull()
        val rawPath = rawUri?.path.orEmpty().trimEnd('/').lowercase(Locale.ROOT)
        if (rawPath.endsWith("/responses")) return "openai-responses"
        if (rawPath.endsWith("/messages")) return "anthropic-messages"
        val uri = runCatching { URI(normalizeBaseUrl(raw)) }.getOrNull()
        val host = uri?.host.orEmpty().lowercase(Locale.ROOT)
        val path = uri?.path.orEmpty().trimEnd('/').lowercase(Locale.ROOT)
        val isLoopback = host == "localhost" || host == "127.0.0.1" || host.trim('[', ']') == "::1"
        val localPort = uri?.port ?: -1
        return when {
            path.contains("/anthropic") || host == "api.anthropic.com" || host.contains("anthropic") -> "anthropic-messages"
            path.endsWith("/v1") -> "openai-completions"
            isLoopback && localPort in setOf(11434, 1234, 8080) -> "openai-completions"
            LocalNetwork.isLocalHost(host) && localPort in setOf(11434, 1234, 8080) -> "openai-completions"
            else -> "anthropic-messages"
        }
    }

    fun destination(raw: String): Destination {
        val uri = runCatching { URI(raw.trim()) }.getOrNull() ?: return Destination.INVALID
        val scheme = uri.scheme?.lowercase(Locale.ROOT)
        val host = uri.host ?: return Destination.INVALID
        if (scheme !in setOf("http", "https") || host.isBlank()) return Destination.INVALID
        if (scheme == "http" && !LocalNetwork.isPlainHttpAllowed(uri.toString())) {
            return Destination.INSECURE_REMOTE_HTTP
        }
        if (host.equals("localhost", true) || host == "127.0.0.1" || host == "::1") return Destination.DEVICE_LOCAL
        if (LocalNetwork.isLocalHost(host)) return Destination.PRIVATE_NETWORK
        return Destination.REMOTE_HTTPS
    }
}
