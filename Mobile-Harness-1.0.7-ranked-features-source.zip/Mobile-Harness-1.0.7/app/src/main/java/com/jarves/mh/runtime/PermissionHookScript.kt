package com.jarves.mh.runtime

/** Builds the guest-side Claude permission hook. Any missing response, timeout, or malformed answer denies. */
object PermissionHookScript {
    const val MIN_TIMEOUT_SECONDS = 30
    const val MAX_TIMEOUT_SECONDS = 600
    const val DEFAULT_TIMEOUT_SECONDS = 300

    fun create(timeoutSeconds: Int = DEFAULT_TIMEOUT_SECONDS): String {
        val timeout = timeoutSeconds.coerceIn(MIN_TIMEOUT_SECONDS, MAX_TIMEOUT_SECONDS)
        // '§' is a placeholder to keep Kotlin from interpolating the shell's $variables.
        return """#!/bin/sh
set -eu
bridge=/pocket-bridge
id="perm-§§-§(date +%s%N)"
request="§bridge/§id.request"
response="§bridge/§id.response"
tmp="§request.tmp.§§"
cat > "§tmp"
mv "§tmp" "§request"
count=0
while [ ! -f "§response" ]; do
  if [ "§count" -ge $timeout ]; then
    rm -f "§tmp" "§request" "§response"
    printf '%s\n' '{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"deny","message":"Approval timed out; action denied."}}}'
    exit 0
  fi
  sleep 1
  count=§((count + 1))
done
decision="§(cat "§response" 2>/dev/null || printf deny)"
rm -f "§tmp" "§request" "§response"
if [ "§decision" = "allow" ]; then
  printf '%s\n' '{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}'
else
  printf '%s\n' '{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"deny","message":"The user denied this action."}}}'
fi
""".replace('§', '$')
    }
}
