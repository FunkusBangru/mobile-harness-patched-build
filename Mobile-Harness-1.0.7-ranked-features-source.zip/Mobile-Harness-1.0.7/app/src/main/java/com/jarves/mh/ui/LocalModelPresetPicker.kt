package com.jarves.mh.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarves.mh.model.LocalModelPreset
import com.jarves.mh.network.ProviderEndpointTools

/** Small reusable local model picker shared by onboarding, settings and the agent workspace. */
@Composable
fun LocalModelPresetPicker(
    onSelect: (LocalModelPreset) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Quick setup: local model server")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            LocalModelPreset.all.forEach { preset ->
                DropdownMenuItem(
                    text = {
                        Column(Modifier.padding(vertical = 2.dp)) {
                            Text(preset.name, style = MaterialTheme.typography.bodyMedium)
                            Text(preset.baseUrl, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    onClick = {
                        expanded = false
                        onSelect(preset)
                    },
                )
            }
        }
        Text(
            "Presets only fill connection settings. Start the server and load a model separately; use Discover models to select an installed model.",
            fontSize = 11.sp,
            lineHeight = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun ProviderEndpointPrivacyHint(url: String) {
    val destination = remember(url) { ProviderEndpointTools.destination(url) }
    if (url.isBlank()) return
    val tint = if (destination.warning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
    Text(
        "${destination.title}: ${destination.detail}",
        fontSize = 11.sp,
        lineHeight = 15.sp,
        color = tint,
    )
}
